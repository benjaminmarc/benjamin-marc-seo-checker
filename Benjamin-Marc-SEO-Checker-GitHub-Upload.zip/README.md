# Benjamin Marc SEO Checker

A free, lightweight, read-only SEO checklist for published WordPress posts and pages, developed by [Benjamin Marc](https://www.benjaminmarc.com/), a Long Island and New York City web design and SEO agency.

**Official website:** [Benjamin Marc — Web Design & SEO](https://www.benjaminmarc.com/)

## Features

- Checks whether a published post or page has a title.
- Looks for saved meta descriptions in Yoast SEO, Rank Math, and legacy All in One SEO metadata keys.
- Counts H1 headings in saved post content and flags anything other than one.
- Flags images in saved post content with missing or empty ALT attributes.
- Displays a paginated review table under **Tools → BM SEO Checker**.
- Does not change site content or send data to external services.

## Requirements

- WordPress 6.0 or newer
- PHP 7.4 or newer
- A WordPress account with the `edit_others_posts` capability to access the report

## Installation

1. Download this repository as a ZIP or obtain the plugin files.
2. If using the repository ZIP, extract it and create a ZIP containing the `benjamin-marc-seo-checker` folder (the folder containing `benjamin-marc-seo-checker.php`).
3. In WordPress admin, open **Plugins → Add New Plugin → Upload Plugin**.
4. Upload that plugin ZIP and activate it.
5. Open **Tools → BM SEO Checker** to review published posts and pages.

See [INSTALLATION.txt](INSTALLATION.txt) for additional notes.

## Limitations

This tool checks **saved post/page content**, not the fully rendered website or page-builder output. Themes may add headings and images that it does not see. Dynamically generated SEO descriptions may not be detected. Empty ALT text can be intentional for decorative images. The plugin does not crawl links, make HTTP requests, or automatically fix issues.

**Testing status:** The supplied plugin package states that it has not been tested on a live WordPress installation. Test on a staging site before using in production.

## Source and licensing

- Plugin version: **1.0.1**
- License: **GPL-2.0-or-later** (see plugin headers and [readme.txt](readme.txt))
- Author: [Benjamin Marc](https://www.benjaminmarc.com/)

## Professional SEO services

For website design, technical SEO, and digital marketing services in Long Island and New York City, visit **[BenjaminMarc.com](https://www.benjaminmarc.com/)**.
